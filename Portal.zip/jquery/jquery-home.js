/*Now nothing to do with this code  /// ************ONLY NEED IS WHEN WE ARE GOING TO SHOW USER ACCOUNT SETTINGS*******************
$(document).ready(function()
{
  
//Here we are ****Temporarly HIDING ***** CAMERA *********
  $("#camera").show();
  $("#select-mood-1").hide();
  $("#select-mood-2").hide();

  //this is line is an example
  $("#agree-to").hide();
  
  //To close the camera  
  $("#yes-button").click(function()
  {
    $("#camera").hide(1000);
    $("#select-mood-1").show(1000);
    $("#select-mood-2").show(1000);
  });

  $("#no-button").click(function()
  {
    $("#camera").hide(1000);
    $("#select-mood-1").show(1000);
    $("#select-mood-2").show(1000);
  });
  
});  