/*
$(document).ready(function()
{
  $("#forgot-div").hide();
  $("#agree-to").hide();
  
  //To open "your agree to our terms and conditions" by clicking on "confirm-password"  
  $("#confirm-password").click(function()
  {
    $("#agree-to").show(1000);
  });

  //To open forgot-box after clicking on forgot password
  $("#forgot-text").click(function()
  {
    $("#forgot-div").show(1000);
  });

  //To hide forgot-box after clicking on up-arrow
  $("#up-arrow").click(function()
  {
    $("#forgot-div").hide(1000);
  });


  
});  