$(document).ready(function()
{
  
  $("#select-reason-1").hide();
  $("#select-reason-2").hide();
  $("#back-button").hide();
  
  //To close the mood-div  
  $("#form-option").click(function()
  {
    $("#select-mood-1").hide(1000);
    $("#select-mood-2").hide(1000);
    $("#back-button").show(1000);
    $("#select-reason-1").show(1000);
    $("#select-reason-2").show(1000);
     
  });

  $("#back-button").click(function()
  {
    $("#select-reason-1").hide(1000);
    $("#select-reason-2").hide(1000);
    $("#back-button").hide(1000);
    $("#select-mood-1").show(1000);
    $("#select-mood-2").show(1000);
    
  });

  
});  